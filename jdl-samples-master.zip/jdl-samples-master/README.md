# Sample JDL files for JHipster

This repository is a showcase of JDL schema files that are generated from JDL Studio.

Please add your own or create an issue if you'd like to see a particular one added.
