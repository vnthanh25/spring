'use strict';
angular.module('webApp', [ 'ngRoute' ]);
