# spring-angular-starter
Spring Boot web and security starters, with an AngularJS page with mock controls.

## Build
run 'bower install' to grab dependencies

run 'mvn spring-boot:run' to run

## Source
Code from https://github.com/dsyer/spring-security-angular/tree/master/single
